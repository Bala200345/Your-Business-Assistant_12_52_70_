import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener
{
    int f=0;
    JTextField tfusername,tfpassword;
    Login()
    {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("Image/Login.jpg"));
        Image i2 = i1.getImage().getScaledInstance(
            Toolkit.getDefaultToolkit().getScreenSize().width,
            Toolkit.getDefaultToolkit().getScreenSize().height,
            Image.SCALE_SMOOTH
        );
        JLabel image = new JLabel(new ImageIcon(i2));
        Dimension screenSize = getToolkit().getScreenSize();
        image.setSize(screenSize.width, screenSize.height);
        getContentPane().add(image);

        JLabel info=new JLabel("   Login with the Adminstrator Credentials");
        info.setBounds(520,250,750,60);
        info.setFont(new Font("serif",Font.BOLD,40));
        info.setForeground(Color.black);
        info.setBackground(new Color(255, 255, 255, 80));
        info.setOpaque(true);
        image.add(info);

        JLabel lblusername=new JLabel("  Username");
        lblusername.setBounds(600,400,150,60);
        lblusername.setFont(new Font("serif",Font.BOLD,30));
        lblusername.setForeground(Color.black);
        lblusername.setBackground(new Color(255, 255, 255, 80));
        lblusername.setOpaque(true);
        image.add(lblusername);

        tfusername=new JTextField();
        tfusername.setBounds(800,400,300,60);
        tfusername.setFont(new Font("Segoe UI light",Font.PLAIN,30));
        tfusername.setForeground(Color.black);
        tfusername.setBackground(new Color(255, 255, 255, 250));
        tfusername.setOpaque(true);
        image.add(tfusername);

        JLabel lblpassword=new JLabel("  Password");
        lblpassword.setBounds(600,500,150,60);
        lblpassword.setFont(new Font("serif",Font.BOLD,30));
        lblpassword.setForeground(Color.black);
        lblpassword.setBackground(new Color(255, 255, 255, 80));
        lblpassword.setOpaque(true);
        image.add(lblpassword);

        tfpassword=new JTextField();
        tfpassword.setBounds(800,500,300,60);
        tfpassword.setFont(new Font("Segoe UI light",Font.PLAIN,30));
        tfpassword.setForeground(Color.black);
        tfpassword.setBackground(new Color(255, 255, 255, 250));
        tfpassword.setOpaque(true);
        image.add(tfpassword);

        JButton login=new JButton("Login");
        login.setBounds(750,600,150,60);
        login.setBackground(new Color(255, 255, 255, 150));
        login.setForeground(Color.black);
        login.setFont(new Font("serif",Font.BOLD, 30));
        login.addActionListener(this);
        image.add(login);

        setSize(1920,1080);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae)
    {
        try
        {
            String Username=tfusername.getText();
            String Password=tfpassword.getText();
            Connect c=new Connect();
            String query="select * from login where username='"+Username+"' and password='"+Password+"' ";
            ResultSet rs=c.s.executeQuery(query);
            if(rs.next())
            {
                setVisible(false);
                new Employee();
            }
            else 
            {
                JOptionPane.showMessageDialog(null,"Invalid username or password");
                f++;
                if(f==3)
                    setVisible(false);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public static void main(String args[])   
    {
        new Login();
    }
}