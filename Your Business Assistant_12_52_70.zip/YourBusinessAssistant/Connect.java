import java.sql.*;
public class Connect
{
    Connection c;
    Statement s;
    public Connect()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");  //registering driver class
            c=DriverManager.getConnection("jdbc:mysql:///ems","root","12122013");   //creating connection string
            s=c.createStatement();  //creating statement
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}