import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Splash extends JFrame implements ActionListener
{
    Splash()
    {
        //super("Your Business Assistant");        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("Image/Splash.png"));
        Image i2 = i1.getImage().getScaledInstance(
            Toolkit.getDefaultToolkit().getScreenSize().width,
            Toolkit.getDefaultToolkit().getScreenSize().height,
            Image.SCALE_SMOOTH
        );
        JLabel image = new JLabel(new ImageIcon(i2));
        Dimension screenSize = getToolkit().getScreenSize();
        image.setSize(screenSize.width, screenSize.height);
        getContentPane().add(image);
        
        JLabel heading=new JLabel("YOUR BUSINESS ASSISTANT");
        heading.setBounds(100,60,800,60);
        heading.setFont(new Font("serif",Font.PLAIN,60));
        heading.setForeground(Color.black);
        heading.setBackground(new Color(255, 255, 255, 128));
        heading.setOpaque(true);
        image.add(heading);
        
        JTextArea info = new JTextArea("\n    Indian women are increasingly contributing to small businesses in the country. They are venturing into various fields, including handicrafts, textiles, beauty products, and food. They are also breaking the gender barriers and stereotypes associated with the business world.\n\n     Studies have shown that women-run small businesses have a positive impact on society as socially responsible, with a greater focus on environmental sustainability and community development.\n\n     Despite numerous challenges such as lack of financial and resource access and struggle with managing finances, inventory, and customer data, they are determined to succeed. They are utilizing technology and business management tools to improve their operations and compete globally.\n\n      That's where \"Your Business Assistant\" comes in as a game-changing solution for small business owners, particularly women entrepreneurs.");
        info.setLineWrap(true);
        info.setWrapStyleWord(true);
        info.setAlignmentX(Component.CENTER_ALIGNMENT);
        info.setFocusable(false);
        info.setBounds(75,190,900,650);
        info.setFont(new Font("Segoe UI ",Font.ITALIC,25));
        info.setForeground(Color.black);
        info.setBackground(new Color(255, 255, 255, 128));
        info.setOpaque(true);
        image.add(info);

        JLabel love=new JLabel(" Made with Love");
        love.setBounds(75,950,250,60);
        love.setFont(new Font("Brush Script MT", Font.ITALIC, 40));
        love.setForeground(Color.black);
        love.setBackground(new Color(255, 255, 255, 128));
        love.setOpaque(true);
        image.add(love);

        JButton clickhere=new JButton("Proceed to Grow with us");
        clickhere.setBounds(1000,400,350,70);
        clickhere.setBackground(new Color(155, 213, 170, 128));
        clickhere.setForeground(Color.black);
        clickhere.setFont(new Font("Brush Script MT", Font.ITALIC, 30));
        clickhere.addActionListener(this);
        clickhere.setLocation(620,950);
        image.add(clickhere);
                
        setSize(1920,1080);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae)
    {
        setVisible(false);
        new Login();
    }

    public static void main(String args[])
    {
        new Splash();
    }
}