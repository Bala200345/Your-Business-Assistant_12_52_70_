import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
public class Employee extends JFrame implements ActionListener
{
    JButton add,update,view,remove,attendance,attendancer,backhome;
    Employee()
    {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("Image/Home.png"));
        Image i2 = i1.getImage().getScaledInstance(
            Toolkit.getDefaultToolkit().getScreenSize().width,
            Toolkit.getDefaultToolkit().getScreenSize().height,
            Image.SCALE_SMOOTH
        );
        JLabel image = new JLabel(new ImageIcon(i2));
        Dimension screenSize = getToolkit().getScreenSize();
        image.setSize(screenSize.width, screenSize.height);
        getContentPane().add(image);

        JLabel heading=new JLabel("Your Business Assistant");
        heading.setBounds(100,60,600,60);
        heading.setFont(new Font("serif",Font.PLAIN,60));
        heading.setForeground(Color.black);
        heading.setBackground(new Color(255, 255, 255, 150));
        heading.setOpaque(true);
        image.add(heading);

        JLabel heading2=new JLabel("Employee Management System");
        heading2.setBounds(100,150,600,60);
        heading2.setFont(new Font("serif",Font.PLAIN,40));
        heading2.setForeground(Color.black);
        heading2.setBackground(new Color(255, 255, 255, 150));
        heading2.setOpaque(true);
        image.add(heading2);

        add=new JButton("Add Employee");
        add.setBounds(1100,300,250,40);
        add.setBackground(new Color(255, 255, 255, 250));
        add.setForeground(Color.black);
        add.setFont(new Font("serif",Font.BOLD, 25));
        add.addActionListener(this);  
        image.add(add);

        view=new JButton("View Employee");
        view.setBounds(1550,300,250,40);
        view.setBackground(new Color(255, 255, 255, 250));
        view.setForeground(Color.black);
        view.setFont(new Font("serif",Font.BOLD, 25));
        view.addActionListener(this);  
        image.add(view);

        update=new JButton("Update Employee");
        update.setBounds(1100,400,250,40);
        update.setBackground(new Color(255, 255, 255, 250));
        update.setForeground(Color.black);
        update.setFont(new Font("serif",Font.BOLD, 25));
        update.addActionListener(this);  
        image.add(update);

        remove=new JButton("Remove Employee");
        remove.setBounds(1550,400,250,40);
        remove.setBackground(new Color(255, 255, 255, 250));
        remove.setForeground(Color.black);
        remove.setFont(new Font("serif",Font.BOLD, 25));
        remove.addActionListener(this);  
        image.add(remove);

        attendance=new JButton("Attendance");
        attendance.setBounds(1100,500,250,40);
        attendance.setBackground(new Color(255, 255, 255, 250));
        attendance.setForeground(Color.black);
        attendance.setFont(new Font("serif",Font.BOLD, 25));
        attendance.addActionListener(this);  
        image.add(attendance);

        attendancer=new JButton("Attendance Records");
        attendancer.setBounds(1550,500,250,40);
        attendancer.setBackground(new Color(255, 255, 255, 250));
        attendancer.setForeground(Color.black);
        attendancer.setFont(new Font("serif",Font.BOLD, 25));
        attendancer.addActionListener(this);  
        image.add(attendancer);

        backhome=new JButton("Exit");
        backhome.setBounds(1550,950,250,40);
        backhome.setBackground(new Color(255, 255, 255, 200));
        backhome.setForeground(Color.black);
        backhome.setFont(new Font("serif",Font.BOLD, 30));
        backhome.addActionListener(this);  
        image.add(backhome);

        setSize(1920,1080);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==add)
        {
            setVisible(false);
            new AddEmployee();
        }
        else if(ae.getSource()==view)
        {
            setVisible(false);
            new ViewEmployee();
        }
        else if(ae.getSource()==update)
        {
            setVisible(false);
            new ViewEmployee();
        }
        else if(ae.getSource()==attendance)
        {
            setVisible(false);
            new Attendance();
        }
        else if(ae.getSource()==attendancer)
        {
            setVisible(false);
            new AttendanceRecord();
        }
        else if(ae.getSource()==remove)
        {
            setVisible(false);
            new RemoveEmployee();            
        }
        else
        {
            setVisible(false);
            System.exit(0);
        }
    }

    public static void main(String args[])
    {
        new Employee();
    }    
}
