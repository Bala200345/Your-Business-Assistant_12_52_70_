import javax.swing.*;
import java.awt.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;
import java.awt.event.*;

public class ViewEmployee extends JFrame implements ActionListener
{
    JTable table;
    Choice employeeid;
    JButton search,print,update,back,backhome;

    ViewEmployee()
    {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("Image/Employee.png"));
        Image i2 = i1.getImage().getScaledInstance(
            Toolkit.getDefaultToolkit().getScreenSize().width,
            Toolkit.getDefaultToolkit().getScreenSize().height,
            Image.SCALE_SMOOTH
        );
        JLabel image = new JLabel(new ImageIcon(i2));
        Dimension screenSize = getToolkit().getScreenSize();
        image.setSize(screenSize.width, screenSize.height);
        getContentPane().add(image);

        JLabel heading=new JLabel("Your Business Assistant");
        heading.setBounds(100,60,600,60);
        heading.setFont(new Font("serif",Font.PLAIN,60));
        heading.setForeground(Color.black);
        heading.setBackground(new Color(255, 255, 255, 150));
        heading.setOpaque(true);
        image.add(heading);

        JLabel heading2=new JLabel("Employee Management");
        heading2.setBounds(100,150,600,60);
        heading2.setFont(new Font("serif",Font.PLAIN,40));
        heading2.setForeground(Color.black);
        heading2.setBackground(new Color(255, 255, 255, 150));
        heading2.setOpaque(true);
        image.add(heading2);

        JLabel searchlbl=new JLabel("Search by Employee ID");
        searchlbl.setBounds(100,300,250,40);
        searchlbl.setBackground(new Color(255, 255, 255, 250));
        searchlbl.setForeground(Color.black);
        searchlbl.setFont(new Font("serif",Font.BOLD, 25)); 
        image.add(searchlbl);

        employeeid=new Choice();
        employeeid.setBounds(100,360,150,20);
        image.add(employeeid);

        try
        {
            Connect c=new Connect();
            ResultSet rs=c.s.executeQuery("select * from employee");

            while(rs.next())
            {
                employeeid.add(rs.getString("id"));
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        table=new JTable();
        table.setBackground(new Color(255, 255, 255, 120));
        table.setForeground(Color.black);
        table.setOpaque(true);
        try
        {
            Connect c=new Connect();
            ResultSet rs=c.s.executeQuery("select * from employee");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        search=new JButton("Search");
        search.setBounds(100,400,250,40);
        search.setBackground(new Color(255, 255, 255, 250));
        search.setForeground(Color.black);
        search.setFont(new Font("serif",Font.BOLD, 25));
        search.addActionListener(this);  
        image.add(search);

        update=new JButton("Update");
        update.setBounds(400,400,250,40);
        update.setBackground(new Color(255, 255, 255, 250));
        update.setForeground(Color.black);
        update.setFont(new Font("serif",Font.BOLD, 25));
        update.addActionListener(this);  
        image.add(update);

        print=new JButton("Print");
        print.setBounds(700,400,250,40);
        print.setBackground(new Color(255, 255, 255, 250));
        print.setForeground(Color.black);
        print.setFont(new Font("serif",Font.BOLD, 25));
        print.addActionListener(this);  
        image.add(print);

        back=new JButton("Employee page");
        back.setBounds(1000,400,250,40);
        back.setBackground(new Color(255, 255, 255, 200));
        back.setForeground(Color.black);
        back.setFont(new Font("serif",Font.BOLD, 30));
        back.addActionListener(this);  
        image.add(back);

        backhome=new JButton("Exit");
        backhome.setBounds(1400,400,250,40);
        backhome.setBackground(new Color(255, 255, 255, 200));
        backhome.setForeground(Color.black);
        backhome.setFont(new Font("serif",Font.BOLD, 30));
        backhome.addActionListener(this);  
        image.add(backhome);

        JScrollPane jsp=new JScrollPane(table);
        jsp.setBounds(20,500,1880,500);
        image.add(jsp);

        setSize(1920,1080);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==search)
        {
            String query="select * from employee where id= '"+employeeid.getSelectedItem()+"' ";
            try
            {
                Connect c=new Connect();
                ResultSet rs=c.s.executeQuery(query);
                table.setModel(DbUtils.resultSetToTableModel(rs));
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        else if(ae.getSource()==print)
        {
            try
            {
                table.print();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        else if(ae.getSource()==update)
        {
            setVisible(false);
            new UpdateEmployee(employeeid.getSelectedItem());
        }
        else if(ae.getSource()==back)
        {
            setVisible(false);
            new Employee();
        }
        else
        {
            setVisible(false);
            System.exit(0);
        }
    }

    public static void main(String args[])
    {
        new ViewEmployee();
    }    
}