import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Home extends JFrame implements ActionListener
{
    JButton employee;
    Home()
    {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("Image/Home.png"));
        Image i2 = i1.getImage().getScaledInstance(
            Toolkit.getDefaultToolkit().getScreenSize().width,
            Toolkit.getDefaultToolkit().getScreenSize().height,
            Image.SCALE_SMOOTH
        );
        JLabel image = new JLabel(new ImageIcon(i2));
        Dimension screenSize = getToolkit().getScreenSize();
        image.setSize(screenSize.width, screenSize.height);
        getContentPane().add(image);

        JLabel heading=new JLabel("Your Business Assistant");
        heading.setBounds(100,60,600,60);
        heading.setFont(new Font("serif",Font.PLAIN,60));
        heading.setForeground(Color.black);
        heading.setBackground(new Color(255, 255, 255, 128));
        heading.setOpaque(true);
        image.add(heading);

        employee=new JButton("Employee Management");
        employee.setBounds(100,300,300,60); 
        employee.setBackground(new Color(255, 255, 255, 150));
        employee.setForeground(Color.black);
        employee.setFont(new Font("serif",Font.BOLD, 25));
        employee.addActionListener(this);  
        image.add(employee);

        setSize(1920,1080);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==employee)
        {
            setVisible(false);
            new Employee();
        }
    }
    
    public static void main(String args[])
    {
        new Home();
    }
}
