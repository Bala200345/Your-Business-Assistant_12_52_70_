import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class RemoveEmployee extends JFrame implements ActionListener
{
    Choice cempid;
    JButton remove,back,backhome;
    RemoveEmployee()
    {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("Image/download.jpg"));
        Image i2 = i1.getImage().getScaledInstance(
            Toolkit.getDefaultToolkit().getScreenSize().width,
            Toolkit.getDefaultToolkit().getScreenSize().height,
            Image.SCALE_SMOOTH
        );
        JLabel image = new JLabel(new ImageIcon(i2));
        Dimension screenSize = getToolkit().getScreenSize();
        image.setSize(screenSize.width, screenSize.height);
        getContentPane().add(image);

        JLabel heading=new JLabel("Your Business Assistant");
        heading.setBounds(100,60,600,60);
        heading.setFont(new Font("serif",Font.PLAIN,60));
        heading.setForeground(Color.black);
        heading.setBackground(new Color(255, 255, 255, 150));
        heading.setOpaque(true);
        image.add(heading);

        JLabel heading2=new JLabel("Remove Employee");
        heading2.setBounds(100,150,600,60);
        heading2.setFont(new Font("serif",Font.PLAIN,40));
        heading2.setForeground(Color.black);
        heading2.setBackground(new Color(255, 255, 255, 150));
        heading2.setOpaque(true);
        image.add(heading2);

        JLabel labelempid=new JLabel("Employee ID");
        labelempid.setBounds(479,300,200,40);
        labelempid.setFont(new Font("serif",Font.BOLD,30));
        labelempid.setForeground(Color.black);
        labelempid.setBackground(new Color(255, 255, 255, 200));
        labelempid.setOpaque(true);
        image.add(labelempid);

        cempid=new Choice();
        cempid.setBounds(680,300,150,60);
        image.add(cempid);

        try
        {
            Connect c=new Connect();
            String query="select * from employee";
            ResultSet rs=c.s.executeQuery(query);
            while(rs.next())
                cempid.add(rs.getString("id"));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        JLabel labelname=new JLabel("  Name");
        labelname.setBounds(100,400,150,40);
        labelname.setFont(new Font("serif",Font.BOLD,30));
        labelname.setForeground(Color.black);
        labelname.setBackground(new Color(255, 255, 255, 200));
        labelname.setOpaque(true);
        image.add(labelname);

        JLabel tfname=new JLabel();
        tfname.setBounds(300,400,300,40);
        tfname.setFont(new Font("Segoe UI light",Font.PLAIN,30));
        tfname.setForeground(Color.black);
        tfname.setBackground(new Color(255, 255, 255, 250));
        tfname.setOpaque(true);
        image.add(tfname);

        JLabel labeladd=new JLabel("  Address");
        labeladd.setBounds(700,400,150,40);
        labeladd.setFont(new Font("serif",Font.BOLD,30));
        labeladd.setForeground(Color.black);
        labeladd.setBackground(new Color(255, 255, 255, 200));
        labeladd.setOpaque(true);
        image.add(labeladd);

        JLabel tfadd=new JLabel();
        tfadd.setBounds(900,400,300,40);
        tfadd.setFont(new Font("Segoe UI light",Font.PLAIN,30));
        tfadd.setForeground(Color.black);
        tfadd.setBackground(new Color(255, 255, 255, 250));
        tfadd.setOpaque(true);
        image.add(tfadd);

        JLabel labelph=new JLabel("  Ph no.");
        labelph.setBounds(100,500,150,40);
        labelph.setFont(new Font("serif",Font.BOLD,30));
        labelph.setForeground(Color.black);
        labelph.setBackground(new Color(255, 255, 255, 200));
        labelph.setOpaque(true);
        image.add(labelph);

        JLabel tfph=new JLabel();
        tfph.setBounds(300,500,300,40);
        tfph.setFont(new Font("Segoe UI light",Font.PLAIN,30));
        tfph.setForeground(Color.black);
        tfph.setBackground(new Color(255, 255, 255, 250));
        tfph.setOpaque(true);
        image.add(tfph);

        JLabel labelpos=new JLabel("  Job");
        labelpos.setBounds(700,500,150,40);
        labelpos.setFont(new Font("serif",Font.BOLD,30));
        labelpos.setForeground(Color.black);
        labelpos.setBackground(new Color(255, 255, 255, 200));
        labelpos.setOpaque(true);
        image.add(labelpos);

        JLabel tfpos=new JLabel();
        tfpos.setBounds(900,500,300,40);
        tfpos.setFont(new Font("Segoe UI light",Font.PLAIN,30));
        tfpos.setForeground(Color.black);
        tfpos.setBackground(new Color(255, 255, 255, 250));
        tfpos.setOpaque(true);
        image.add(tfpos);

        JLabel labelsal=new JLabel("  Salary");
        labelsal.setBounds(100,600,150,40);
        labelsal.setFont(new Font("serif",Font.BOLD,30));
        labelsal.setForeground(Color.black);
        labelsal.setBackground(new Color(255, 255, 255, 200));
        labelsal.setOpaque(true);
        image.add(labelsal);

        JLabel tfsal=new JLabel();
        tfsal.setBounds(300,600,300,40);
        tfsal.setFont(new Font("Segoe UI light",Font.PLAIN,30));
        tfsal.setForeground(Color.black);
        tfsal.setBackground(new Color(255, 255, 255, 250));
        tfsal.setOpaque(true);
        image.add(tfsal);

        JLabel labeldoj=new JLabel("Date of Joining");
        labeldoj.setBounds(700,600,150,40);
        labeldoj.setFont(new Font("serif",Font.BOLD,30));
        labeldoj.setForeground(Color.black);
        labeldoj.setBackground(new Color(255, 255, 255, 200));
        labeldoj.setOpaque(true);
        image.add(labeldoj);

        JLabel dcdoj=new JLabel();
        dcdoj.setBounds(900,600,300,40);
        dcdoj.setFont(new Font("Segoe UI light",Font.PLAIN,30));
        dcdoj.setForeground(Color.black);
        dcdoj.setBackground(new Color(255, 255, 255, 200));
        dcdoj.setOpaque(true);
        image.add(dcdoj);

        try
        {
            Connect c=new Connect();
            String query="select * from employee where id= '"+cempid.getSelectedItem()+"' ";
            ResultSet rs=c.s.executeQuery(query);
            while(rs.next())
            {
                tfname.setText(rs.getString("name"));
                tfadd.setText(rs.getString("address"));
                tfph.setText(rs.getString("phno"));
                tfpos.setText(rs.getString("job"));
                tfsal.setText(rs.getString("salary"));
                dcdoj.setText(rs.getString("doj"));
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        cempid.addItemListener(new ItemListener()
        {
            public void itemStateChanged(ItemEvent ie)
            {
                try
                {
                    Connect c=new Connect();
                    String query="select * from employee where id= '"+cempid.getSelectedItem()+"' ";
                    ResultSet rs=c.s.executeQuery(query);
                    while(rs.next())
                    {
                        tfname.setText(rs.getString("name"));
                        tfadd.setText(rs.getString("address"));
                        tfph.setText(rs.getString("phno"));
                        tfpos.setText(rs.getString("job"));
                        tfsal.setText(rs.getString("salary"));
                        dcdoj.setText(rs.getString("doj"));
                    }
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
            }
        });

        remove=new JButton("Remove Employee");
        remove.setBounds(535,800,270,40);
        remove.setBackground(new Color(255, 255, 255, 200));
        remove.setForeground(Color.black);
        remove.setFont(new Font("serif",Font.BOLD, 30));
        remove.addActionListener(this);  
        image.add(remove);

        back=new JButton("Employee page");
        back.setBounds(400,900,250,40);
        back.setBackground(new Color(255, 255, 255, 200));
        back.setForeground(Color.black);
        back.setFont(new Font("serif",Font.BOLD, 30));
        back.addActionListener(this);  
        image.add(back);

        backhome=new JButton("Exit");
        backhome.setBounds(700,900,250,40);
        backhome.setBackground(new Color(255, 255, 255, 200));
        backhome.setForeground(Color.black);
        backhome.setFont(new Font("serif",Font.BOLD, 30));
        backhome.addActionListener(this);  
        image.add(backhome);

        setSize(1920,1080);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==remove)
        {
            try
            {
                Connect c=new Connect();
                String query="delete from employee where id= '"+cempid.getSelectedItem()+"' ";
                c.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null,"Employee removed successfully.");
                setVisible(false);
                new Employee();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

        }
        else if(ae.getSource()==backhome)
        {
            setVisible(false);
            System.exit(0);  
        }
        else
        {
            setVisible(false);
            new Employee();
        }

    }

    public static void main(String args[])
    {
        new RemoveEmployee();
    }
    
}
