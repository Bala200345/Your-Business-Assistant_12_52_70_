import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import java.time.*;

public class Attendance extends JFrame implements ActionListener
{
    JTable table;
    Choice att,id;
    JButton submit,print,back,backhome;
    Attendance()
    {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("Image/download.jpg"));
        Image i2 = i1.getImage().getScaledInstance(
            Toolkit.getDefaultToolkit().getScreenSize().width,
            Toolkit.getDefaultToolkit().getScreenSize().height,
            Image.SCALE_SMOOTH
        );
        JLabel image = new JLabel(new ImageIcon(i2));
        Dimension screenSize = getToolkit().getScreenSize();
        image.setSize(screenSize.width, screenSize.height);
        getContentPane().add(image);

        JLabel heading=new JLabel("Your Business Assistant");
        heading.setBounds(100,60,600,60);
        heading.setFont(new Font("serif",Font.PLAIN,60));
        heading.setForeground(Color.black);
        heading.setBackground(new Color(255, 255, 255, 150));
        heading.setOpaque(true);
        image.add(heading);

        JLabel heading2=new JLabel("Employee Attendance");
        heading2.setBounds(100,150,600,60);
        heading2.setFont(new Font("serif",Font.PLAIN,40));
        heading2.setForeground(Color.black);
        heading2.setBackground(new Color(255, 255, 255, 150));
        heading2.setOpaque(true);
        image.add(heading2);

        JLabel labelempid=new JLabel("Employee ID");
        labelempid.setBounds(479,300,200,40);
        labelempid.setFont(new Font("serif",Font.BOLD,30));
        labelempid.setForeground(Color.black);
        labelempid.setBackground(new Color(255, 255, 255, 200));
        labelempid.setOpaque(true);
        image.add(labelempid);

        id=new Choice();
        id.setBounds(680,300,150,40);
        image.add(id);

        try
        {
            Connect c=new Connect();
            String query="select * from employee";
            ResultSet rs=c.s.executeQuery(query);
            while(rs.next())
                id.add(rs.getString("id"));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        JLabel labelname=new JLabel("  Name");
        labelname.setBounds(100,400,150,40);
        labelname.setFont(new Font("serif",Font.BOLD,30));
        labelname.setForeground(Color.black);
        labelname.setBackground(new Color(255, 255, 255, 200));
        labelname.setOpaque(true);
        image.add(labelname);

        JLabel tfname=new JLabel();
        tfname.setBounds(300,400,300,40);
        tfname.setFont(new Font("Segoe UI light",Font.PLAIN,30));
        tfname.setForeground(Color.black);
        tfname.setBackground(new Color(255, 255, 255, 250));
        tfname.setOpaque(true);
        image.add(tfname);

        JLabel date=new JLabel("Date");
        date.setBounds(700,400,150,40);
        date.setFont(new Font("serif",Font.BOLD,30));
        date.setForeground(Color.black);
        date.setBackground(new Color(255, 255, 255, 200));
        date.setOpaque(true);
        image.add(date);

        LocalDate today=LocalDate.now();
        JLabel tfdate=new JLabel(today.toString());
        tfdate.setBounds(900,400,300,40);
        tfdate.setFont(new Font("Segoe UI light",Font.PLAIN,30));
        tfdate.setForeground(Color.black);
        tfdate.setBackground(new Color(255, 255, 255, 250));
        tfdate.setOpaque(true);
        image.add(tfdate);

        JLabel Att=new JLabel("Attendance");
        Att.setBounds(100,500,150,40);
        Att.setSize(150,40);
        Att.setFont(new Font("serif",Font.BOLD,30));
        Att.setForeground(Color.black);
        Att.setBackground(new Color(255, 255, 255, 200));
        Att.setOpaque(true);
        image.add(Att);

        att=new Choice();
        att.setBounds(300,500,100,60);
        att.add("Present");
        att.add("Absent");
        image.add(att);

        try
        {
            Connect c=new Connect();
            String query="select name from employee where id= '"+id.getSelectedItem()+"' ";
            ResultSet rs=c.s.executeQuery(query);
            while(rs.next())
                tfname.setText(rs.getString("name"));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        id.addItemListener(new ItemListener()
        {
            public void itemStateChanged(ItemEvent ie)
            {
                try
                {
                    Connect c=new Connect();
                    String query="select name from employee where id= '"+id.getSelectedItem()+"' ";
                    ResultSet rs=c.s.executeQuery(query);
                    while(rs.next())
                        tfname.setText(rs.getString("name"));    
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
            }
        });

        submit=new JButton("Submit");
        submit.setBounds(535,800,270,40);
        submit.setBackground(new Color(255, 255, 255, 200));
        submit.setForeground(Color.black);
        submit.setFont(new Font("serif",Font.BOLD, 30));
        submit.addActionListener(this);  
        image.add(submit);

        back=new JButton("Employee page");
        back.setBounds(400,900,250,40);
        back.setBackground(new Color(255, 255, 255, 200));
        back.setForeground(Color.black);
        back.setFont(new Font("serif",Font.BOLD, 30));
        back.addActionListener(this);  
        image.add(back);

        backhome=new JButton("Exit");
        backhome.setBounds(700,900,250,40);
        backhome.setBackground(new Color(255, 255, 255, 200));
        backhome.setForeground(Color.black);
        backhome.setFont(new Font("serif",Font.BOLD, 30));
        backhome.addActionListener(this);  
        image.add(backhome);

        setSize(1920,1080);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==submit)
        {
            String cid=id.getSelectedItem();
            String d=LocalDate.now().toString();
            String atte=att.getSelectedItem();
            try
            {
                Connect c=new Connect();
                String query="insert into attendance(date,id,att) values('"+d+"','"+cid+"', '"+atte+"')";
                c.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null,"Attendance marked successfully.");
                setVisible(false);
                new Employee();                
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        else if(ae.getSource()==print)
        {
            try
            {
                table.print();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        else if(ae.getSource()==back)
        {
            setVisible(false);
            new Employee();
        }
        else
        {
            setVisible(false);
            System.exit(0);
        }
    }

    public static void main(String args[])
    {
        new Attendance();
    }
}
